# enemies.py
# Neon Platformlar, Hareketli Platformlar, Lazer/Diken Tuzakları, Devriye Düşmanlar ve Bölüm Sonu Portalı

import math
import pygame
from settings import (
    SCREEN_WIDTH, SCREEN_HEIGHT,
    NEON_CYAN, NEON_MAGENTA, NEON_PINK, NEON_PURPLE,
    NEON_YELLOW, NEON_GREEN, NEON_RED, NEON_ORANGE,
    WHITE, DARK_METAL, GRID_COLOR
)


class NeonPlatform:
    """Statik cyberpunk neon platform."""
    def __init__(self, x, y, w, h, color=NEON_CYAN):
        self.rect = pygame.Rect(int(x), int(y), int(w), int(h))
        self.color = color

    def draw(self, surface, camera_x, camera_y):
        sx = self.rect.x - int(camera_x)
        sy = self.rect.y - int(camera_y)
        if sx > SCREEN_WIDTH + 60 or sx + self.rect.w < -60 or sy > SCREEN_HEIGHT + 60 or sy + self.rect.h < -60:
            return

        draw_rect = pygame.Rect(sx, sy, self.rect.w, self.rect.h)
        pygame.draw.rect(surface, (16, 18, 36), draw_rect, border_radius=4)

        # İç siber devre çizgileri
        for gx in range(sx + 16, sx + self.rect.w - 8, 24):
            pygame.draw.line(surface, GRID_COLOR, (gx, sy + 4), (gx, sy + self.rect.h - 4), 1)

        # Neon çerçeve ve parlak üst şerit
        pygame.draw.rect(surface, self.color, draw_rect, width=2, border_radius=4)
        pygame.draw.line(surface, WHITE, (sx + 3, sy + 2), (sx + self.rect.w - 4, sy + 2), 2)


class MovingPlatform:
    """Yatay veya dikey eksende devriye gezen hareketli neon platform."""
    def __init__(self, x, y, w, h, move_x=0, move_y=0, speed=2.2, color=NEON_GREEN):
        self.start_x = float(x)
        self.start_y = float(y)
        self.pos_x = float(x)
        self.pos_y = float(y)
        self.rect = pygame.Rect(int(x), int(y), int(w), int(h))
        self.move_x = float(move_x)
        self.move_y = float(move_y)
        self.speed = float(speed)
        self.color = color
        self.progress = 0.0
        self.direction = 1
        self.delta_x = 0.0
        self.delta_y = 0.0

        dist = math.hypot(self.move_x, self.move_y)
        self.step = (self.speed / dist) if dist > 0 else 0.0

    def update(self, dt_ms):
        dt_scale = min(2.5, dt_ms / 16.67)
        old_x = self.rect.x
        old_y = self.rect.y

        self.progress += self.step * self.direction * dt_scale
        if self.progress >= 1.0:
            self.progress = 1.0
            self.direction = -1
        elif self.progress <= 0.0:
            self.progress = 0.0
            self.direction = 1

        # Yumuşak sinüzoidal geçiş
        smooth_t = 0.5 - 0.5 * math.cos(self.progress * math.pi)
        self.pos_x = self.start_x + self.move_x * smooth_t
        self.pos_y = self.start_y + self.move_y * smooth_t
        self.rect.x = int(round(self.pos_x))
        self.rect.y = int(round(self.pos_y))

        self.delta_x = self.rect.x - old_x
        self.delta_y = self.rect.y - old_y

    def draw(self, surface, camera_x, camera_y):
        # Ray izini çiz
        x1 = int(self.start_x + self.rect.w // 2 - camera_x)
        y1 = int(self.start_y + self.rect.h // 2 - camera_y)
        x2 = int(self.start_x + self.move_x + self.rect.w // 2 - camera_x)
        y2 = int(self.start_y + self.move_y + self.rect.h // 2 - camera_y)
        pygame.draw.line(surface, (40, 75, 85), (x1, y1), (x2, y2), 2)
        pygame.draw.circle(surface, self.color, (x1, y1), 4)
        pygame.draw.circle(surface, self.color, (x2, y2), 4)

        sx = self.rect.x - int(camera_x)
        sy = self.rect.y - int(camera_y)
        draw_rect = pygame.Rect(sx, sy, self.rect.w, self.rect.h)
        pygame.draw.rect(surface, (20, 32, 42), draw_rect, border_radius=5)
        pygame.draw.rect(surface, self.color, draw_rect, width=2, border_radius=5)
        pygame.draw.line(surface, WHITE, (sx + 4, sy + 2), (sx + self.rect.w - 5, sy + 2), 2)

        # Alt itici (thruster) alevleri
        flame_h = 5 + int(abs(math.sin(pygame.time.get_ticks() * 0.02)) * 6)
        pygame.draw.polygon(
            surface, NEON_CYAN,
            [(sx + 12, sy + self.rect.h), (sx + 20, sy + self.rect.h), (sx + 16, sy + self.rect.h + flame_h)]
        )
        pygame.draw.polygon(
            surface, NEON_CYAN,
            [(sx + self.rect.w - 20, sy + self.rect.h), (sx + self.rect.w - 12, sy + self.rect.h),
             (sx + self.rect.w - 16, sy + self.rect.h + flame_h)]
        )


class SpikeTrap:
    """Yüzey üzerinde parlayan plazma diken tuzağı."""
    def __init__(self, x, y, width=48, height=18):
        self.rect = pygame.Rect(int(x), int(y), int(width), int(height))
        self.damage = 25

    def draw(self, surface, camera_x, camera_y):
        sx = self.rect.x - int(camera_x)
        sy = self.rect.y - int(camera_y)
        if sx > SCREEN_WIDTH + 50 or sx + self.rect.w < -50:
            return

        spike_w = 12
        num_spikes = max(1, self.rect.w // spike_w)
        for i in range(num_spikes):
            bx = sx + i * spike_w
            pts = [
                (bx, sy + self.rect.h),
                (bx + spike_w // 2, sy),
                (bx + spike_w, sy + self.rect.h)
            ]
            pygame.draw.polygon(surface, (50, 10, 28), pts)
            pygame.draw.polygon(surface, NEON_RED, pts, 2)
            pygame.draw.line(surface, WHITE, (bx + spike_w // 2, sy + 2), (bx + spike_w // 2, sy + self.rect.h - 3), 1)


class LaserTrap:
    """Zamanlamalı açılıp kapanan dikey veya yatay yüksek enerjili lazer tuzağı."""
    def __init__(self, x, y, length, vertical=True, active_ms=1600, cooldown_ms=1300, phase_offset_ms=0):
        self.x = int(x)
        self.y = int(y)
        self.length = int(length)
        self.vertical = vertical
        self.active_ms = active_ms
        self.cooldown_ms = cooldown_ms
        self.cycle_ms = active_ms + cooldown_ms
        self.timer_ms = phase_offset_ms % self.cycle_ms
        self.damage = 30

        if self.vertical:
            self.rect = pygame.Rect(self.x - 5, self.y, 10, self.length)
        else:
            self.rect = pygame.Rect(self.x, self.y - 5, self.length, 10)

    @property
    def is_active(self):
        return self.timer_ms < self.active_ms

    @property
    def is_warning(self):
        return not self.is_active and (self.cycle_ms - self.timer_ms) < 450

    def update(self, dt_ms):
        self.timer_ms = (self.timer_ms + dt_ms) % self.cycle_ms

    def draw(self, surface, camera_x, camera_y):
        sx = self.x - int(camera_x)
        sy = self.y - int(camera_y)
        if sx < -200 or sx > SCREEN_WIDTH + 200:
            return

        if self.vertical:
            p1 = (sx, sy)
            p2 = (sx, sy + self.length)
        else:
            p1 = (sx, sy)
            p2 = (sx + self.length, sy)

        # Lazer emiter başlıkları
        pygame.draw.circle(surface, DARK_METAL, p1, 7)
        pygame.draw.circle(surface, NEON_RED, p1, 7, 2)
        pygame.draw.circle(surface, DARK_METAL, p2, 7)
        pygame.draw.circle(surface, NEON_RED, p2, 7, 2)

        if self.is_active:
            pulse = int(3 + 2 * abs(math.sin(pygame.time.get_ticks() * 0.03)))
            pygame.draw.line(surface, NEON_RED, p1, p2, pulse * 2 + 2)
            pygame.draw.line(surface, NEON_PINK, p1, p2, pulse)
            pygame.draw.line(surface, WHITE, p1, p2, 2)
        elif self.is_warning:
            # Ateşlenmeden hemen önce kesikli uyarı çizgisi
            if (int(pygame.time.get_ticks() // 60) % 2) == 0:
                pygame.draw.line(surface, NEON_ORANGE, p1, p2, 1)


class PatrolDrone:
    """Devriye gezen siber güvenlik dronu / robotu.
    Üzerine zıplayarak (stomp) veya Dash atarak yok edilebilir.
    """
    def __init__(self, x, y, patrol_dist=140, speed=2.4):
        self.start_x = float(x)
        self.pos_x = float(x)
        self.pos_y = float(y)
        self.patrol_dist = float(patrol_dist)
        self.speed = float(speed)
        self.rect = pygame.Rect(int(x), int(y), 36, 36)
        self.direction = 1
        self.alive = True
        self.damage = 25

    def update(self, dt_ms):
        if not self.alive:
            return
        dt_scale = min(2.5, dt_ms / 16.67)
        self.pos_x += self.speed * self.direction * dt_scale
        if self.pos_x > self.start_x + self.patrol_dist:
            self.pos_x = self.start_x + self.patrol_dist
            self.direction = -1
        elif self.pos_x < self.start_x:
            self.pos_x = self.start_x
            self.direction = 1

        bob = math.sin(pygame.time.get_ticks() * 0.008 + self.start_x) * 3.0
        self.rect.x = int(round(self.pos_x))
        self.rect.y = int(round(self.pos_y + bob))

    def draw(self, surface, camera_x, camera_y):
        if not self.alive:
            return
        sx = self.rect.x - int(camera_x)
        sy = self.rect.y - int(camera_y)
        if sx < -60 or sx > SCREEN_WIDTH + 60:
            return

        cx = sx + self.rect.w // 2
        cy = sy + self.rect.h // 2

        # Dış hale
        glow_surf = pygame.Surface((60, 60), pygame.SRCALPHA)
        pygame.draw.circle(glow_surf, (*NEON_RED, 55), (30, 30), 24)
        surface.blit(glow_surf, (cx - 30, cy - 30), special_flags=pygame.BLEND_ADD)

        # Sekizgen / Elmas Siber Gövde
        pts = [
            (cx, sy),
            (sx + self.rect.w, cy - 5),
            (sx + self.rect.w - 4, sy + self.rect.h),
            (sx + 4, sy + self.rect.h),
            (sx, cy - 5),
        ]
        pygame.draw.polygon(surface, (28, 16, 38), pts)
        pygame.draw.polygon(surface, NEON_RED, pts, 2)

        # Kırmızı Tarayıcı Göz (Scanner Eye)
        eye_x = cx + (6 if self.direction > 0 else -6)
        pygame.draw.circle(surface, NEON_ORANGE, (eye_x, cy), 6)
        pygame.draw.circle(surface, WHITE, (eye_x, cy), 3)


class DataShard:
    """Skor kazandıran parlayan siber veri kristali."""
    def __init__(self, x, y):
        self.base_x = int(x)
        self.base_y = int(y)
        self.rect = pygame.Rect(self.base_x - 10, self.base_y - 10, 20, 20)
        self.collected = False
        self.value = 100

    def draw(self, surface, camera_x, camera_y, time_ms):
        if self.collected:
            return
        sx = self.base_x - int(camera_x)
        sy = self.base_y - int(camera_y) + int(math.sin(time_ms * 0.006 + self.base_x) * 4)
        if sx < -40 or sx > SCREEN_WIDTH + 40:
            return

        pts = [
            (sx, sy - 11),
            (sx + 9, sy),
            (sx, sy + 11),
            (sx - 9, sy)
        ]
        pygame.draw.polygon(surface, NEON_YELLOW, pts)
        pygame.draw.polygon(surface, WHITE, pts, 2)


class CyberPortal:
    """Bölüm sonu kuantum neon portalı."""
    def __init__(self, x, y):
        self.x = int(x)
        self.y = int(y)
        self.rect = pygame.Rect(self.x - 28, self.y - 44, 56, 88)

    def draw(self, surface, camera_x, camera_y, time_ms):
        sx = self.x - int(camera_x)
        sy = self.y - int(camera_y)
        if sx < -100 or sx > SCREEN_WIDTH + 100:
            return

        # Parlayan dış aura
        glow = pygame.Surface((140, 160), pygame.SRCALPHA)
        pygame.draw.ellipse(glow, (*NEON_CYAN, 55), (10, 10, 120, 140))
        pygame.draw.ellipse(glow, (*NEON_MAGENTA, 85), (26, 24, 88, 112))
        surface.blit(glow, (sx - 70, sy - 80), special_flags=pygame.BLEND_ADD)

        # Dönen enerji halkaları
        for i in range(4):
            angle = time_ms * 0.004 * (1 if i % 2 == 0 else -1) + i * 1.2
            rx = 22 - i * 4 + int(math.sin(angle) * 3)
            ry = 40 - i * 6
            col = NEON_CYAN if i % 2 == 0 else NEON_MAGENTA
            ring_rect = pygame.Rect(sx - rx, sy - ry, rx * 2, ry * 2)
            pygame.draw.ellipse(surface, col, ring_rect, 3)

        # Merkez beyaz çekirdek
        pygame.draw.ellipse(surface, WHITE, (sx - 8, sy - 18, 16, 36))

        # Alt kaide
        pygame.draw.rect(surface, DARK_METAL, (sx - 34, sy + 42, 68, 10), border_radius=3)
        pygame.draw.rect(surface, NEON_CYAN, (sx - 34, sy + 42, 68, 10), width=2, border_radius=3)
