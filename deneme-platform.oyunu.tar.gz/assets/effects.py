# effects.py
# Parçacık Efektleri, Neon İz (Trail), Ekran Titremesi (Screen Shake) ve Paralaks Arka Plan

import math
import random
import pygame
from settings import (
    SCREEN_WIDTH, SCREEN_HEIGHT,
    BG_TOP, BG_BOTTOM, NEON_CYAN, NEON_MAGENTA, NEON_PINK,
    NEON_PURPLE, NEON_YELLOW, NEON_GREEN, WHITE
)


class ScreenShake:
    """Ekran titremesi (screen shake) yöneticisi."""
    def __init__(self):
        self.duration_ms = 0
        self.intensity = 0
        self.offset_x = 0
        self.offset_y = 0

    def trigger(self, intensity=8, duration_ms=200):
        self.intensity = max(self.intensity, intensity)
        self.duration_ms = max(self.duration_ms, duration_ms)

    def update(self, dt_ms):
        if self.duration_ms > 0:
            self.duration_ms -= dt_ms
            current_int = int(self.intensity * max(0.2, min(1.0, self.duration_ms / 250.0)))
            if current_int > 0:
                self.offset_x = random.randint(-current_int, current_int)
                self.offset_y = random.randint(-current_int, current_int)
            else:
                self.offset_x = 0
                self.offset_y = 0
            if self.duration_ms <= 0:
                self.intensity = 0
                self.offset_x = 0
                self.offset_y = 0
        else:
            self.offset_x = 0
            self.offset_y = 0


class Particle:
    """Tekil prosedürel neon parçacık."""
    def __init__(self, x, y, vx, vy, color, size, lifetime_ms, gravity=0.15, glow=True, shape="circle"):
        self.x = float(x)
        self.y = float(y)
        self.vx = float(vx)
        self.vy = float(vy)
        self.color = color
        self.initial_size = float(size)
        self.size = float(size)
        self.lifetime_ms = float(lifetime_ms)
        self.max_lifetime_ms = float(lifetime_ms)
        self.gravity = gravity
        self.glow = glow
        self.shape = shape

    def update(self, dt_ms):
        self.lifetime_ms -= dt_ms
        self.x += self.vx * (dt_ms / 16.67)
        self.y += self.vy * (dt_ms / 16.67)
        self.vy += self.gravity * (dt_ms / 16.67)
        ratio = max(0.0, self.lifetime_ms / self.max_lifetime_ms)
        self.size = max(1.0, self.initial_size * ratio)

    def draw(self, surface, camera_x, camera_y):
        if self.lifetime_ms <= 0:
            return
        sx = int(self.x - camera_x)
        sy = int(self.y - camera_y)
        if sx < -50 or sx > SCREEN_WIDTH + 50 or sy < -50 or sy > SCREEN_HEIGHT + 50:
            return

        r = int(self.size)
        if self.glow and r >= 2:
            glow_r = r * 2 + 2
            glow_surf = pygame.Surface((glow_r * 2, glow_r * 2), pygame.SRCALPHA)
            alpha = int(95 * (self.lifetime_ms / self.max_lifetime_ms))
            pygame.draw.circle(glow_surf, (*self.color, alpha), (glow_r, glow_r), glow_r)
            surface.blit(glow_surf, (sx - glow_r, sy - glow_r), special_flags=pygame.BLEND_ADD)

        if self.shape == "rect":
            pygame.draw.rect(surface, self.color, (sx - r, sy - r, r * 2, r * 2))
        elif self.shape == "spark":
            end_x = int(sx - self.vx * 1.8)
            end_y = int(sy - self.vy * 1.8)
            pygame.draw.line(surface, self.color, (sx, sy), (end_x, end_y), max(1, r // 2))
        else:
            pygame.draw.circle(surface, self.color, (sx, sy), max(1, r))


class AfterImage:
    """Dash veya yüksek hız sırasında oyuncunun arkasında bıraktığı neon hayalet izi."""
    def __init__(self, x, y, width, height, color, facing_right=True):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
        self.facing_right = facing_right
        self.lifetime_ms = 240.0
        self.max_lifetime_ms = 240.0

    def update(self, dt_ms):
        self.lifetime_ms -= dt_ms

    def draw(self, surface, camera_x, camera_y):
        if self.lifetime_ms <= 0:
            return
        ratio = max(0.0, self.lifetime_ms / self.max_lifetime_ms)
        alpha = int(160 * ratio)
        surf = pygame.Surface((self.width + 12, self.height + 12), pygame.SRCALPHA)

        # Gövde silüeti
        body_rect = pygame.Rect(6, 6, self.width, self.height)
        pygame.draw.rect(surf, (*self.color, alpha), body_rect, border_radius=6)
        pygame.draw.rect(surf, (*WHITE, int(alpha * 0.7)), body_rect, width=2, border_radius=6)

        # Visor izi
        visor_x = 18 if self.facing_right else 8
        pygame.draw.rect(surf, (*WHITE, alpha), (visor_x, 14, 14, 6), border_radius=2)

        sx = int(self.x - camera_x - 6)
        sy = int(self.y - camera_y - 6)
        surface.blit(surf, (sx, sy), special_flags=pygame.BLEND_ADD)


class ParticleSystem:
    """Tüm parçacık ve neon iz efektlerini yöneten sınıf."""
    def __init__(self):
        self.particles = []
        self.afterimages = []

    def clear(self):
        self.particles.clear()
        self.afterimages.clear()

    def emit_jump(self, x, y, is_double=False):
        color = NEON_MAGENTA if is_double else NEON_CYAN
        count = 18 if is_double else 12
        for _ in range(count):
            vx = random.uniform(-3.8, 3.8)
            vy = random.uniform(-1.5, 2.2)
            size = random.uniform(3.0, 5.5)
            life = random.uniform(220, 420)
            self.particles.append(
                Particle(x + random.uniform(-10, 10), y, vx, vy, color, size, life, gravity=0.05, shape="rect")
            )

    def emit_land(self, x, y, impact_speed=8.0):
        count = min(22, max(8, int(impact_speed * 1.4)))
        for _ in range(count):
            side = random.choice([-1, 1])
            vx = side * random.uniform(1.2, 4.8)
            vy = random.uniform(-3.2, -0.5)
            color = random.choice([NEON_CYAN, NEON_PINK, WHITE])
            size = random.uniform(2.5, 5.0)
            life = random.uniform(180, 360)
            self.particles.append(
                Particle(x + side * random.uniform(0, 8), y, vx, vy, color, size, life, gravity=0.18, shape="spark")
            )

    def emit_dash(self, x, y, direction):
        for _ in range(20):
            vx = -direction * random.uniform(2.5, 7.5) + random.uniform(-1.0, 1.0)
            vy = random.uniform(-2.5, 2.5)
            color = random.choice([NEON_CYAN, NEON_MAGENTA, WHITE])
            size = random.uniform(3.0, 6.0)
            life = random.uniform(200, 380)
            self.particles.append(
                Particle(x, y + random.uniform(-16, 16), vx, vy, color, size, life, gravity=0.0, shape="spark")
            )

    def emit_explosion(self, x, y, color=NEON_MAGENTA, count=32):
        for _ in range(count):
            angle = random.uniform(0, math.tau)
            speed = random.uniform(2.0, 8.5)
            vx = math.cos(angle) * speed
            vy = math.sin(angle) * speed
            c = random.choice([color, NEON_YELLOW, WHITE, NEON_CYAN])
            size = random.uniform(3.5, 7.0)
            life = random.uniform(300, 650)
            self.particles.append(
                Particle(x, y, vx, vy, c, size, life, gravity=0.14, shape="rect")
            )

    def emit_collect(self, x, y):
        for _ in range(18):
            angle = random.uniform(0, math.tau)
            speed = random.uniform(1.5, 5.5)
            vx = math.cos(angle) * speed
            vy = math.sin(angle) * speed
            c = random.choice([NEON_YELLOW, NEON_GREEN, NEON_CYAN, WHITE])
            self.particles.append(
                Particle(x, y, vx, vy, c, random.uniform(3, 5.5), random.uniform(240, 450), gravity=0.04)
            )

    def add_afterimage(self, x, y, w, h, color, facing_right):
        self.afterimages.append(AfterImage(x, y, w, h, color, facing_right))

    def update(self, dt_ms):
        for p in self.particles:
            p.update(dt_ms)
        self.particles = [p for p in self.particles if p.lifetime_ms > 0]

        for a in self.afterimages:
            a.update(dt_ms)
        self.afterimages = [a for a in self.afterimages if a.lifetime_ms > 0]

    def draw(self, surface, camera_x, camera_y):
        for a in self.afterimages:
            a.draw(surface, camera_x, camera_y)
        for p in self.particles:
            p.draw(surface, camera_x, camera_y)


class ParallaxBackground:
    """Prosedürel çok katmanlı Cyberpunk arka planı."""
    def __init__(self):
        # Dikey renk geçişli gökyüzü yüzeyi önbelleği
        self.gradient_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self._build_gradient()

        # Uzak yıldızlar / siber noktalar
        random.seed(42)
        self.stars = [
            (
                random.randint(0, SCREEN_WIDTH),
                random.randint(0, int(SCREEN_HEIGHT * 0.65)),
                random.choice([NEON_CYAN, NEON_PINK, WHITE, NEON_PURPLE]),
                random.uniform(1.0, 2.5),
                random.uniform(0.0, math.tau)
            )
            for _ in range(75)
        ]

        # Katman 1: Uzak silüet gökdelenler (parallax factor: 0.12)
        self.far_buildings = self._generate_skyline(
            count=28, min_w=70, max_w=135, min_h=180, max_h=430,
            base_color=(16, 12, 38), window_colors=[NEON_PURPLE, NEON_PINK]
        )

        # Katman 2: Orta mesafe neon kuleler (parallax factor: 0.28)
        self.mid_buildings = self._generate_skyline(
            count=24, min_w=85, max_w=160, min_h=120, max_h=330,
            base_color=(22, 18, 52), window_colors=[NEON_CYAN, NEON_MAGENTA, NEON_YELLOW]
        )

        # Siber yağmur damlaları
        self.rain_drops = [
            [random.randint(0, SCREEN_WIDTH), random.randint(0, SCREEN_HEIGHT), random.uniform(9, 15)]
            for _ in range(65)
        ]
        random.seed()

    def _build_gradient(self):
        for y in range(SCREEN_HEIGHT):
            t = y / float(SCREEN_HEIGHT)
            r = int(BG_TOP[0] * (1 - t) + BG_BOTTOM[0] * t)
            g = int(BG_TOP[1] * (1 - t) + BG_BOTTOM[1] * t)
            b = int(BG_TOP[2] * (1 - t) + BG_BOTTOM[2] * t)
            pygame.draw.line(self.gradient_surf, (r, g, b), (0, y), (SCREEN_WIDTH, y))

    def _generate_skyline(self, count, min_w, max_w, min_h, max_h, base_color, window_colors):
        buildings = []
        x_cursor = 0
        for _ in range(count):
            w = random.randint(min_w, max_w)
            h = random.randint(min_h, max_h)
            has_antenna = random.random() < 0.45
            antenna_h = random.randint(25, 65) if has_antenna else 0
            trim_color = random.choice(window_colors)

            windows = []
            cols = max(2, (w - 16) // 18)
            rows = max(3, (h - 24) // 24)
            for r in range(rows):
                for c in range(cols):
                    if random.random() < 0.35:
                        wx = 10 + c * 18
                        wy = 16 + r * 24
                        w_col = random.choice(window_colors)
                        windows.append((wx, wy, w_col))

            buildings.append({
                "x": x_cursor,
                "w": w,
                "h": h,
                "color": base_color,
                "trim_color": trim_color,
                "antenna_h": antenna_h,
                "windows": windows,
            })
            x_cursor += w + random.randint(6, 26)
        self.total_span = max(2400, x_cursor)
        return buildings

    def draw(self, surface, camera_x, camera_y, time_ms):
        # 1) Gökyüzü gradyanı
        surface.blit(self.gradient_surf, (0, 0))

        # 2) Synthwave Neon Güneş / Sibernetik Ay
        sun_x = int(SCREEN_WIDTH * 0.76 - camera_x * 0.03) % (SCREEN_WIDTH + 200) - 100
        sun_y = int(SCREEN_HEIGHT * 0.26 - camera_y * 0.02)
        sun_radius = 88
        sun_surf = pygame.Surface((sun_radius * 4, sun_radius * 4), pygame.SRCALPHA)
        center = sun_radius * 2
        pygame.draw.circle(sun_surf, (*NEON_MAGENTA, 40), (center, center), int(sun_radius * 1.45))
        pygame.draw.circle(sun_surf, (*NEON_PINK, 120), (center, center), sun_radius)
        pygame.draw.circle(sun_surf, (*NEON_YELLOW, 160), (center, center), int(sun_radius * 0.78))
        # Yatay synthwave çizgileri
        for stripe_y in range(center, center + sun_radius, 12):
            pygame.draw.line(
                sun_surf, (0, 0, 0, 190),
                (center - sun_radius, stripe_y),
                (center + sun_radius, stripe_y),
                4
            )
        surface.blit(sun_surf, (sun_x - center, sun_y - center))

        # 3) Parlayan yıldızlar
        for sx, sy, col, sz, phase in self.stars:
            pulse = 0.65 + 0.35 * math.sin(time_ms * 0.004 + phase)
            px = int((sx - camera_x * 0.05) % SCREEN_WIDTH)
            py = int(sy - camera_y * 0.02)
            if 0 <= py < SCREEN_HEIGHT:
                c = (int(col[0] * pulse), int(col[1] * pulse), int(col[2] * pulse))
                pygame.draw.circle(surface, c, (px, py), int(sz))

        # 4) Uzak ve Orta Katman Gökdelenler
        self._draw_building_layer(surface, self.far_buildings, camera_x, camera_y, 0.14, 0.05, draw_details=False)
        self._draw_building_layer(surface, self.mid_buildings, camera_x, camera_y, 0.30, 0.10, draw_details=True)

        # 5) Siber Yağmur Çizgileri
        for drop in self.rain_drops:
            drop[0] = (drop[0] - 2.2) % SCREEN_WIDTH
            drop[1] = (drop[1] + drop[2]) % SCREEN_HEIGHT
            x1, y1 = int(drop[0]), int(drop[1])
            pygame.draw.line(surface, (40, 140, 185), (x1, y1), (x1 - 3, y1 + 11), 1)

    def _draw_building_layer(self, surface, buildings, camera_x, camera_y, factor_x, factor_y, draw_details=True):
        span = buildings[-1]["x"] + buildings[-1]["w"] + 30
        base_y = int(SCREEN_HEIGHT + 40 - camera_y * factor_y)

        for b in buildings:
            bx = int((b["x"] - camera_x * factor_x) % span) - 160
            by = base_y - b["h"]
            if bx > SCREEN_WIDTH + 50 or bx + b["w"] < -50:
                continue

            rect = pygame.Rect(bx, by, b["w"], b["h"] + 120)
            pygame.draw.rect(surface, b["color"], rect)
            # Neon çatı çizgisi
            pygame.draw.line(surface, b["trim_color"], (bx, by), (bx + b["w"], by), 2)

            if b["antenna_h"] > 0:
                ax = bx + b["w"] // 2
                pygame.draw.line(surface, b["trim_color"], (ax, by - b["antenna_h"]), (ax, by), 2)
                pygame.draw.circle(surface, NEON_PINK, (ax, by - b["antenna_h"]), 3)

            if draw_details:
                for wx, wy, w_col in b["windows"]:
                    if by + wy < SCREEN_HEIGHT:
                        pygame.draw.rect(surface, w_col, (bx + wx, by + wy, 8, 12))
