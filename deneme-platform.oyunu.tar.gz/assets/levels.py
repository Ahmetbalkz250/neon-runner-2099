# levels.py
# 10 Farklı ve Kademeli Zorlaşan/Uzayan Cyberpunk Bölüm Tasarımı

import random
from settings import (
    NEON_CYAN, NEON_MAGENTA, NEON_PINK, NEON_PURPLE,
    NEON_GREEN, NEON_YELLOW, NEON_ORANGE
)
from enemies import (
    NeonPlatform, MovingPlatform, SpikeTrap, LaserTrap,
    PatrolDrone, DataShard, CyberPortal
)


LEVEL_METADATA = {
    1: ("SEKTÖR 01: NEON SOKAKLAR", "ZORLUK: 01 // BAŞLANGIÇ"),
    2: ("SEKTÖR 02: LAZER DÖKÜMHANESİ", "ZORLUK: 02 // KOLAY-ORTA"),
    3: ("SEKTÖR 03: SİBER ÇEKİRDEK", "ZORLUK: 03 // ORTA"),
    4: ("SEKTÖR 04: SENTETİK KANALLAR", "ZORLUK: 04 // ORTA-ÜST"),
    5: ("SEKTÖR 05: VERİ OTOBANI", "ZORLUK: 05 // ZORLAYICI"),
    6: ("SEKTÖR 06: PLAZMA REAKTÖRÜ", "ZORLUK: 06 // ZOR"),
    7: ("SEKTÖR 07: KARANLIK AĞ (DARKNET)", "ZORLUK: 07 // ÇOK ZOR"),
    8: ("SEKTÖR 08: KROM KULELER", "ZORLUK: 08 // UZMAN"),
    9: ("SEKTÖR 09: NÖRAL LABORATUVAR", "ZORLUK: 09 // USTA"),
    10: ("SEKTÖR 10: OMEGA NEXUS", "ZORLUK: 10 // OMEGA (FİNAL)"),
}


class Level:
    def __init__(self, index):
        self.index = max(1, min(10, int(index)))
        self.name, self.difficulty_label = LEVEL_METADATA[self.index]
        self.spawn_pos = (90, 480)
        self.fall_death_y = 1080
        self.platforms = []
        self.moving_platforms = []
        self.spikes = []
        self.lasers = []
        self.drones = []
        self.shards = []
        self.portal = None
        self._build(self.index)

    def _build(self, index):
        if index == 1:
            self._build_level_1()
        elif index == 2:
            self._build_level_2()
        elif index == 3:
            self._build_level_3()
        else:
            self._build_progressive_sector(index)

    def _build_level_1(self):
        self.spawn_pos = (90, 480)
        self.fall_death_y = 980

        self.platforms = [
            NeonPlatform(40, 560, 340, 36, NEON_CYAN),
            NeonPlatform(450, 500, 220, 28, NEON_CYAN),
            NeonPlatform(740, 410, 260, 28, NEON_MAGENTA),
            NeonPlatform(1080, 460, 360, 32, NEON_CYAN),
            NeonPlatform(1520, 380, 200, 26, NEON_PURPLE),
            NeonPlatform(2050, 420, 350, 32, NEON_CYAN),
            NeonPlatform(2480, 340, 180, 26, NEON_MAGENTA),
            NeonPlatform(2740, 270, 320, 36, NEON_GREEN),
        ]

        self.moving_platforms = [
            MovingPlatform(1770, 390, 130, 22, move_x=220, move_y=0, speed=2.2, color=NEON_GREEN),
        ]

        self.spikes = [
            SpikeTrap(1200, 442, width=72, height=18),
        ]

        self.lasers = [
            LaserTrap(2220, 260, length=160, vertical=True, active_ms=1400, cooldown_ms=1550, phase_offset_ms=0),
        ]

        self.drones = [
            PatrolDrone(770, 372, patrol_dist=180, speed=2.0),
            PatrolDrone(2100, 382, patrol_dist=210, speed=2.2),
        ]

        self.shards = [
            DataShard(560, 450),
            DataShard(870, 355),
            DataShard(1235, 395),
            DataShard(1620, 330),
            DataShard(1880, 335),
            DataShard(2570, 290),
        ]

        self.portal = CyberPortal(2960, 226)

    def _build_level_2(self):
        self.spawn_pos = (80, 480)
        self.fall_death_y = 1020

        self.platforms = [
            NeonPlatform(30, 560, 260, 36, NEON_MAGENTA),
            NeonPlatform(380, 500, 190, 26, NEON_CYAN),
            NeonPlatform(660, 520, 460, 32, NEON_PURPLE),
            NeonPlatform(660, 310, 460, 24, NEON_PURPLE),
            NeonPlatform(1520, 430, 260, 30, NEON_CYAN),
            NeonPlatform(1890, 340, 190, 26, NEON_MAGENTA),
            NeonPlatform(2180, 460, 320, 30, NEON_CYAN),
            NeonPlatform(2920, 330, 180, 26, NEON_PINK),
            NeonPlatform(3190, 280, 320, 36, NEON_GREEN),
        ]

        self.moving_platforms = [
            MovingPlatform(1180, 490, 125, 22, move_x=270, move_y=-60, speed=2.5, color=NEON_GREEN),
            MovingPlatform(2560, 450, 125, 22, move_x=280, move_y=-110, speed=2.6, color=NEON_YELLOW),
        ]

        self.spikes = [
            SpikeTrap(435, 482, width=60, height=18),
            SpikeTrap(1610, 412, width=72, height=18),
            SpikeTrap(2300, 442, width=84, height=18),
        ]

        self.lasers = [
            LaserTrap(780, 334, length=186, vertical=True, active_ms=1350, cooldown_ms=1350, phase_offset_ms=0),
            LaserTrap(980, 334, length=186, vertical=True, active_ms=1350, cooldown_ms=1350, phase_offset_ms=1350),
            LaserTrap(1985, 190, length=150, vertical=True, active_ms=1350, cooldown_ms=1250, phase_offset_ms=600),
        ]

        self.drones = [
            PatrolDrone(700, 482, patrol_dist=220, speed=2.5),
            PatrolDrone(2195, 422, patrol_dist=95, speed=2.5),
            PatrolDrone(3210, 242, patrol_dist=140, speed=2.6),
        ]

        self.shards = [
            DataShard(465, 435),
            DataShard(880, 465),
            DataShard(1315, 410),
            DataShard(1645, 365),
            DataShard(1985, 290),
            DataShard(2340, 390),
            DataShard(2700, 345),
            DataShard(3010, 280),
        ]

        self.portal = CyberPortal(3430, 236)

    def _build_level_3(self):
        self.spawn_pos = (70, 500)
        self.fall_death_y = 1060

        self.platforms = [
            NeonPlatform(20, 580, 230, 36, NEON_PINK),
            NeonPlatform(340, 510, 150, 24, NEON_CYAN),
            NeonPlatform(590, 430, 150, 24, NEON_MAGENTA),
            NeonPlatform(840, 470, 440, 30, NEON_PURPLE),
            NeonPlatform(840, 260, 440, 22, NEON_PURPLE),
            NeonPlatform(1720, 380, 300, 28, NEON_CYAN),
            NeonPlatform(2140, 320, 360, 28, NEON_MAGENTA),
            NeonPlatform(2960, 300, 200, 26, NEON_CYAN),
            NeonPlatform(3280, 360, 260, 28, NEON_PURPLE),
            NeonPlatform(3650, 260, 340, 36, NEON_GREEN),
        ]

        self.moving_platforms = [
            MovingPlatform(1350, 460, 120, 22, move_x=290, move_y=-75, speed=2.8, color=NEON_GREEN),
            MovingPlatform(2570, 320, 120, 22, move_x=310, move_y=-20, speed=2.9, color=NEON_YELLOW),
        ]

        self.spikes = [
            SpikeTrap(950, 452, width=60, height=18),
            SpikeTrap(1130, 452, width=60, height=18),
            SpikeTrap(1830, 362, width=72, height=18),
            SpikeTrap(2280, 302, width=72, height=18),
            SpikeTrap(3370, 342, width=60, height=18),
        ]

        self.lasers = [
            LaserTrap(910, 282, length=188, vertical=True, active_ms=1250, cooldown_ms=1150, phase_offset_ms=0),
            LaserTrap(1070, 282, length=188, vertical=True, active_ms=1250, cooldown_ms=1150, phase_offset_ms=750),
            LaserTrap(1230, 282, length=188, vertical=True, active_ms=1250, cooldown_ms=1150, phase_offset_ms=1500),
            LaserTrap(2440, 140, length=180, vertical=True, active_ms=1250, cooldown_ms=1150, phase_offset_ms=300),
            LaserTrap(3060, 120, length=180, vertical=True, active_ms=1200, cooldown_ms=1150, phase_offset_ms=900),
        ]

        self.drones = [
            PatrolDrone(860, 432, patrol_dist=200, speed=2.8),
            PatrolDrone(1740, 342, patrol_dist=230, speed=2.9),
            PatrolDrone(2160, 282, patrol_dist=260, speed=3.0),
            PatrolDrone(3680, 222, patrol_dist=180, speed=3.0),
        ]

        self.shards = [
            DataShard(415, 460),
            DataShard(665, 380),
            DataShard(980, 395),
            DataShard(1160, 395),
            DataShard(1500, 370),
            DataShard(1865, 310),
            DataShard(2315, 250),
            DataShard(2720, 255),
            DataShard(3060, 250),
            DataShard(3410, 290),
        ]

        self.portal = CyberPortal(3910, 216)

    def _build_progressive_sector(self, index):
        """4'ten 10'a kadar her seviyede kademeli olarak daha uzun ve daha zorlayıcı
        deterministik Cyberpunk bölümleri inşa eder."""
        rng = random.Random(1000 + index * 137)
        self.spawn_pos = (70, 500)
        self.fall_death_y = 1080

        # Zorluk katsayısı (0.0 -> Bölüm 4, 1.0 -> Bölüm 10)
        t = (index - 4) / 6.0

        # Her yeni bölüm bir öncekinden 2 modül daha uzun olur (Bölüm 4: 8 modül ... Bölüm 10: 20 modül)
        num_modules = 8 + (index - 4) * 2

        # Hız ve zorluk parametreleri kademeli artar
        drone_speed = 3.05 + (index - 3) * 0.22
        mp_speed = 2.95 + (index - 3) * 0.20
        laser_active_ms = int(1250 - t * 220)      # Lazer açık kalma süresi
        laser_cooldown_ms = int(1150 - t * 280)    # Lazer bekleme süresi kısalır (daha sık ateşlenir)
        plat_shrink = int((index - 3) * 8)         # Platformlar ilerledikçe bir miktar daralır

        palette = [NEON_CYAN, NEON_MAGENTA, NEON_PURPLE, NEON_PINK, NEON_GREEN, NEON_YELLOW]

        # Başlangıç güvenli platformu
        self.platforms.append(NeonPlatform(20, 580, 230, 36, palette[index % len(palette)]))
        cursor_x = 250
        cursor_y = 580

        for m in range(num_modules):
            mod_type = (m + index) % 5
            col = palette[(m + index) % len(palette)]

            if mod_type == 0:
                # MODÜL A: Lazer Kafesi Koridoru + Diken + Devriye Dronu
                gap = rng.randint(115, 145)
                cursor_x += gap
                cursor_y = max(310, min(540, cursor_y + rng.choice([-60, -40, 30, 50])))
                w = max(360, 460 - plat_shrink)
                ceiling_h = 188

                # Alt zemin ve üst tavan
                self.platforms.append(NeonPlatform(cursor_x, cursor_y, w, 30, NEON_PURPLE))
                self.platforms.append(NeonPlatform(cursor_x, cursor_y - ceiling_h - 22, w, 22, NEON_PURPLE))

                # 2 veya 3 zamanlamalı dikey lazer
                laser_count = 2 if index < 7 else 3
                spacing = w // (laser_count + 1)
                for l_idx in range(laser_count):
                    lx = cursor_x + spacing * (l_idx + 1)
                    self.lasers.append(
                        LaserTrap(
                            lx, cursor_y - ceiling_h, length=ceiling_h, vertical=True,
                            active_ms=laser_active_ms, cooldown_ms=laser_cooldown_ms,
                            phase_offset_ms=l_idx * 550
                        )
                    )

                # Lazerler arasına diken ve veri kristali
                spike_x = cursor_x + spacing // 2 + 12
                self.spikes.append(SpikeTrap(spike_x, cursor_y - 18, width=48, height=18))
                self.shards.append(DataShard(cursor_x + w // 2, cursor_y - 65))

                # Koridor dronu
                self.drones.append(
                    PatrolDrone(cursor_x + 30, cursor_y - 38, patrol_dist=w - 100, speed=drone_speed)
                )
                cursor_x += w

            elif mod_type == 1:
                # MODÜL B: Hareketli Platform Köprüsü + Hava Lazeri
                gap = rng.randint(105, 130)
                cursor_x += gap
                mp_w = max(92, 124 - (index - 3) * 3)
                move_x = rng.randint(230, 290)
                move_y = rng.choice([-80, -50, 45, 75])
                target_y = max(280, min(540, cursor_y + move_y))
                actual_dy = target_y - cursor_y

                self.moving_platforms.append(
                    MovingPlatform(
                        cursor_x, cursor_y, mp_w, 22,
                        move_x=move_x, move_y=actual_dy,
                        speed=mp_speed, color=NEON_GREEN if m % 2 == 0 else NEON_YELLOW
                    )
                )
                mid_x = cursor_x + (move_x + mp_w) // 2
                mid_y = cursor_y + actual_dy // 2
                self.shards.append(DataShard(mid_x, mid_y - 55))

                if index >= 5:
                    self.lasers.append(
                        LaserTrap(
                            mid_x, mid_y - 170, length=155, vertical=True,
                            active_ms=laser_active_ms, cooldown_ms=laser_cooldown_ms,
                            phase_offset_ms=(m * 400)
                        )
                    )

                cursor_x += move_x + mp_w
                cursor_y = target_y

            elif mod_type == 2:
                # MODÜL C: İkiz Siber Kule Basamakları (Double Jump & Dash Testi)
                for step in range(2):
                    gap = rng.randint(120, 155)
                    cursor_x += gap
                    cursor_y = max(270, min(550, cursor_y + rng.choice([-75, -55, 45])))
                    w = max(135, 195 - plat_shrink // 2)
                    self.platforms.append(NeonPlatform(cursor_x, cursor_y, w, 26, col))
                    self.shards.append(DataShard(cursor_x + w // 2, cursor_y - 48))

                    if step == 1 and w >= 145:
                        self.spikes.append(SpikeTrap(cursor_x + w // 2 - 24, cursor_y - 18, width=48, height=18))
                    cursor_x += w

            elif mod_type == 3:
                # MODÜL D: Geniş Savunma Platformu (Çift Diken + Hızlı Dron + Lazer)
                gap = rng.randint(115, 150)
                cursor_x += gap
                cursor_y = max(290, min(540, cursor_y + rng.choice([-50, 40, 65])))
                w = max(350, 430 - plat_shrink)
                self.platforms.append(NeonPlatform(cursor_x, cursor_y, w, 30, NEON_MAGENTA))

                self.spikes.append(SpikeTrap(cursor_x + 65, cursor_y - 18, width=60, height=18))
                self.spikes.append(SpikeTrap(cursor_x + w - 125, cursor_y - 18, width=60, height=18))

                self.drones.append(
                    PatrolDrone(cursor_x + 25, cursor_y - 38, patrol_dist=w - 90, speed=drone_speed + 0.2)
                )
                if index >= 7:
                    # Yüksek seviyelerde ikinci bir karşıt devriye dronu
                    self.drones.append(
                        PatrolDrone(cursor_x + 90, cursor_y - 38, patrol_dist=w - 160, speed=drone_speed + 0.45)
                    )

                self.shards.append(DataShard(cursor_x + 95, cursor_y - 68))
                self.shards.append(DataShard(cursor_x + w - 95, cursor_y - 68))
                cursor_x += w

            else:
                # MODÜL E: Yatay Lazer Engelli Siber Köprü
                gap = rng.randint(115, 145)
                cursor_x += gap
                cursor_y = max(300, min(530, cursor_y + rng.choice([-65, 55])))
                w = max(280, 340 - plat_shrink)
                self.platforms.append(NeonPlatform(cursor_x, cursor_y, w, 28, NEON_CYAN))

                # Köprü üstünde ters T şeklindeki yatay + dikey lazer kombinasyonu:
                # Biri söndükten 3.5 saniye (3500 ms) sonra diğeri yanacak şekilde sırayla çalışırlar.
                t_active_ms = 1500
                t_gap_ms = 3500
                t_cooldown_ms = t_active_ms + 2 * t_gap_ms  # 8500 ms (toplam döngü = 10000 ms)
                self.lasers.append(
                    LaserTrap(
                        cursor_x + 40, cursor_y - 26, length=w - 80, vertical=False,
                        active_ms=t_active_ms, cooldown_ms=t_cooldown_ms,
                        phase_offset_ms=0
                    )
                )
                self.lasers.append(
                    LaserTrap(
                        cursor_x + w // 2, cursor_y - 175, length=145, vertical=True,
                        active_ms=t_active_ms, cooldown_ms=t_cooldown_ms,
                        phase_offset_ms=t_active_ms + t_gap_ms  # 5000 ms
                    )
                )
                self.shards.append(DataShard(cursor_x + w // 2, cursor_y - 80))
                cursor_x += w

        # Bölüm Sonu Portal Platformu
        cursor_x += 130
        cursor_y = max(240, min(480, cursor_y - 40))
        final_w = 340
        self.platforms.append(NeonPlatform(cursor_x, cursor_y, final_w, 36, NEON_GREEN))
        self.drones.append(
            PatrolDrone(cursor_x + 20, cursor_y - 38, patrol_dist=150, speed=drone_speed)
        )
        self.shards.append(DataShard(cursor_x + 110, cursor_y - 50))
        self.portal = CyberPortal(cursor_x + final_w - 70, cursor_y - 44)

    def update(self, dt_ms):
        for mp in self.moving_platforms:
            mp.update(dt_ms)
        for laser in self.lasers:
            laser.update(dt_ms)
        for drone in self.drones:
            drone.update(dt_ms)

    def draw(self, surface, camera_x, camera_y, time_ms):
        for plat in self.platforms:
            plat.draw(surface, camera_x, camera_y)
        for mp in self.moving_platforms:
            mp.draw(surface, camera_x, camera_y)
        for spike in self.spikes:
            spike.draw(surface, camera_x, camera_y)
        for laser in self.lasers:
            laser.draw(surface, camera_x, camera_y)
        for shard in self.shards:
            shard.draw(surface, camera_x, camera_y, time_ms)
        for drone in self.drones:
            drone.draw(surface, camera_x, camera_y)
        if self.portal:
            self.portal.draw(surface, camera_x, camera_y, time_ms)
