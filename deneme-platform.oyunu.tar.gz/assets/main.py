# main.py
# 2D Cyberpunk Platformer - Ana Oyun Döngüsü, Menü, HUD ve Durum Yönetimi

import sys
import math
import asyncio
import pygame

IS_WEB = sys.platform == "emscripten"

from settings import (
    SCREEN_WIDTH, SCREEN_HEIGHT, FPS, TITLE,
    PLAYER_MAX_HP, DASH_COOLDOWN_MS, MAX_LEVELS,
    NEON_CYAN, NEON_MAGENTA, NEON_PINK, NEON_PURPLE,
    NEON_YELLOW, NEON_GREEN, NEON_RED, WHITE, DARK_METAL
)
from effects import ScreenShake, ParticleSystem, ParallaxBackground
from player import Player
from levels import Level


class CyberpunkGame:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption(TITLE)
        self.running = True
        if IS_WEB:
            self.is_fullscreen = False
            self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        else:
            self.is_fullscreen = True
            self.screen = pygame.display.set_mode(
                (SCREEN_WIDTH, SCREEN_HEIGHT),
                pygame.SCALED | pygame.FULLSCREEN
            )
        self.clock = pygame.time.Clock()

        # Yazı tipleri (Sistem fontu üzerinden)
        self.font_title = pygame.font.SysFont("dejavusans,arial,sans-serif", 54, bold=True)
        self.font_subtitle = pygame.font.SysFont("dejavusans,arial,sans-serif", 26, bold=True)
        self.font_hud = pygame.font.SysFont("dejavusans,arial,sans-serif", 18, bold=True)
        self.font_small = pygame.font.SysFont("dejavusans,arial,sans-serif", 15, bold=False)

        # Efekt sistemleri
        self.background = ParallaxBackground()
        self.particles = ParticleSystem()
        self.screen_shake = ScreenShake()

        # Oyun durumları: "MENU", "PLAYING", "GAME_OVER", "VICTORY"
        self.state = "MENU"
        self.current_level_idx = 1
        self.max_levels = MAX_LEVELS
        self.score = 0
        self.level_banner_ms = 0

        # Kamera
        self.camera_x = 0.0
        self.camera_y = 0.0

        # Oyuncu ve Bölüm başlatma
        self.level = Level(self.current_level_idx)
        self.player = Player(*self.level.spawn_pos)

    def start_new_game(self, start_level=1):
        self.current_level_idx = start_level
        self.score = 0
        self.load_level(self.current_level_idx, full_heal=True)
        self.state = "PLAYING"

    def load_level(self, idx, full_heal=False):
        self.level = Level(idx)
        prev_hp = self.player.hp
        self.player.reset(*self.level.spawn_pos)
        if not full_heal and prev_hp > 0:
            self.player.hp = prev_hp
        else:
            self.player.hp = PLAYER_MAX_HP

        self.particles.clear()
        self.camera_x = self.player.rect.centerx - SCREEN_WIDTH * 0.35
        self.camera_y = self.player.rect.centery - SCREEN_HEIGHT * 0.58
        self.level_banner_ms = 2400

    def continue_current_level(self):
        """Ölündüğünde kaldığımız sektörden oyuna devam eder."""
        self.score = max(0, self.score - 100)
        self.load_level(self.current_level_idx, full_heal=True)
        self.state = "PLAYING"

    def restart_current(self):
        """R tuşuyla 1. sektöre döner."""
        self.start_new_game(1)

    def toggle_fullscreen(self):
        """F11 ile tam ekran ve pencere modu arasında geçiş yapar."""
        if IS_WEB:
            return
        self.is_fullscreen = not self.is_fullscreen
        flags = (pygame.SCALED | pygame.FULLSCREEN) if self.is_fullscreen else pygame.SCALED
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), flags)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
                return

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_F11:
                    self.toggle_fullscreen()

                if event.key == pygame.K_ESCAPE:
                    if self.state == "PLAYING":
                        self.state = "MENU"
                    elif not IS_WEB:
                        self.running = False
                        return

                # R tuşu ile her an yeniden başlatma
                if event.key == pygame.K_r:
                    self.restart_current()

                if self.state == "MENU":
                    if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                        self.start_new_game(1)
                    elif pygame.K_1 <= event.key <= pygame.K_9:
                        self.start_new_game(event.key - pygame.K_1 + 1)
                    elif event.key == pygame.K_0:
                        self.start_new_game(10)

                elif self.state == "PLAYING":
                    # Zıplama: Space, W veya Yukarı Ok
                    if event.key in (pygame.K_SPACE, pygame.K_w, pygame.K_UP):
                        self.player.request_jump()

                    # Dash (Atılma): Sol/Sağ Shift, K veya X
                    if event.key in (pygame.K_LSHIFT, pygame.K_RSHIFT, pygame.K_k, pygame.K_x):
                        self.player.request_dash(self.particles, self.screen_shake)

                elif self.state == "GAME_OVER":
                    if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                        self.continue_current_level()

                elif self.state == "VICTORY":
                    if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                        self.start_new_game(1)

    def update(self, dt_ms):
        self.screen_shake.update(dt_ms)
        self.particles.update(dt_ms)

        if self.state == "MENU":
            self.camera_x += 1.2 * (dt_ms / 16.67)
            return

        if self.state != "PLAYING":
            return

        if self.level_banner_ms > 0:
            self.level_banner_ms = max(0, self.level_banner_ms - dt_ms)

        keys = pygame.key.get_pressed()
        self.level.update(dt_ms)
        self.player.update(
            dt_ms, keys,
            self.level.platforms,
            self.level.moving_platforms,
            self.particles,
            self.screen_shake
        )

        # Kamera oyuncuyu yumuşak şekilde takip eder
        target_cam_x = self.player.rect.centerx - SCREEN_WIDTH * 0.36
        target_cam_y = self.player.rect.centery - SCREEN_HEIGHT * 0.58
        target_cam_y = max(-180.0, min(200.0, target_cam_y))
        self.camera_x += (target_cam_x - self.camera_x) * 0.12
        self.camera_y += (target_cam_y - self.camera_y) * 0.10

        # 1) Veri Kristalleri (Data Shards) Toplama
        for shard in self.level.shards:
            if not shard.collected and self.player.rect.colliderect(shard.rect):
                shard.collected = True
                self.score += shard.value
                self.particles.emit_collect(shard.base_x, shard.base_y)

        # 2) Diken Tuzakları Çarpışması
        for spike in self.level.spikes:
            if self.player.rect.colliderect(spike.rect):
                kb_dir = -1 if self.player.rect.centerx < spike.rect.centerx else 1
                self.player.take_damage(spike.damage, kb_dir, self.particles, self.screen_shake)

        # 3) Lazer Tuzakları Çarpışması
        for laser in self.level.lasers:
            if laser.is_active and self.player.rect.colliderect(laser.rect):
                kb_dir = -1 if self.player.rect.centerx < laser.rect.centerx else 1
                self.player.take_damage(laser.damage, kb_dir, self.particles, self.screen_shake)

        # 4) Devriye Dronları Çarpışması (Dash veya Üstten Zıplama ile Yok Edilebilir)
        for drone in self.level.drones:
            if not drone.alive:
                continue
            if self.player.rect.colliderect(drone.rect):
                stomp_attack = (self.player.vel_y > 1.5 and self.player.rect.bottom <= drone.rect.centery + 10)
                if self.player.is_dashing or stomp_attack:
                    drone.alive = False
                    self.score += 250
                    self.particles.emit_explosion(drone.rect.centerx, drone.rect.centery, color=NEON_RED, count=36)
                    self.screen_shake.trigger(intensity=9, duration_ms=190)
                    if stomp_attack and not self.player.is_dashing:
                        self.player.vel_y = -11.5
                        self.player.jumps_left = 1
                else:
                    kb_dir = -1 if self.player.rect.centerx < drone.rect.centerx else 1
                    self.player.take_damage(drone.damage, kb_dir, self.particles, self.screen_shake)

        # 5) Boşluğa Düşme Kontrolü
        if self.player.rect.top > self.level.fall_death_y:
            self.player.hp -= 35
            self.screen_shake.trigger(intensity=12, duration_ms=280)
            if self.player.hp > 0:
                curr_hp = self.player.hp
                self.player.reset(*self.level.spawn_pos)
                self.player.hp = curr_hp
                self.player.invulnerable_ms = 1200
            else:
                self.player.hp = 0

        # Can Sıfırlandıysa -> GAME OVER
        if self.player.hp <= 0:
            self.particles.emit_explosion(self.player.rect.centerx, self.player.rect.centery, color=NEON_MAGENTA, count=45)
            self.state = "GAME_OVER"
            return

        # 6) Bölüm Sonu Portalına Ulaşma
        if self.level.portal and self.player.rect.colliderect(self.level.portal.rect):
            self.score += 500
            self.particles.emit_explosion(self.level.portal.x, self.level.portal.y, color=NEON_CYAN, count=45)
            self.screen_shake.trigger(intensity=10, duration_ms=220)
            if self.current_level_idx < self.max_levels:
                self.current_level_idx += 1
                self.load_level(self.current_level_idx, full_heal=True)
            else:
                self.state = "VICTORY"

    def draw_hud(self):
        # Üst yarı saydam siber panel
        hud_panel = pygame.Surface((SCREEN_WIDTH, 66), pygame.SRCALPHA)
        pygame.draw.rect(hud_panel, (10, 8, 26, 210), (0, 0, SCREEN_WIDTH, 66))
        pygame.draw.line(hud_panel, NEON_CYAN, (0, 64), (SCREEN_WIDTH, 64), 2)
        self.screen.blit(hud_panel, (0, 0))

        # 1) CAN GÖSTERGESİ (HP Bar)
        hp_label = self.font_hud.render("SİBER ZIRH (HP)", True, NEON_CYAN)
        self.screen.blit(hp_label, (24, 10))

        bar_x, bar_y, bar_w, bar_h = 24, 34, 220, 18
        pygame.draw.rect(self.screen, DARK_METAL, (bar_x, bar_y, bar_w, bar_h), border_radius=4)
        hp_ratio = max(0.0, min(1.0, self.player.hp / float(PLAYER_MAX_HP)))
        fill_w = int(bar_w * hp_ratio)
        hp_col = NEON_GREEN if hp_ratio > 0.5 else (NEON_YELLOW if hp_ratio > 0.25 else NEON_RED)
        if fill_w > 0:
            pygame.draw.rect(self.screen, hp_col, (bar_x, bar_y, fill_w, bar_h), border_radius=4)
        pygame.draw.rect(self.screen, WHITE, (bar_x, bar_y, bar_w, bar_h), width=2, border_radius=4)

        # 2) DASH (ATILMA) MODÜLÜ GÖSTERGESİ
        dash_label = self.font_hud.render("DASH MODÜLÜ [SHIFT]", True, NEON_MAGENTA)
        self.screen.blit(dash_label, (274, 10))

        d_x, d_y, d_w, d_h = 274, 34, 175, 18
        pygame.draw.rect(self.screen, DARK_METAL, (d_x, d_y, d_w, d_h), border_radius=4)
        dash_ready_ratio = 1.0 - max(0.0, min(1.0, self.player.dash_cooldown_ms / float(DASH_COOLDOWN_MS)))
        d_fill = int(d_w * dash_ready_ratio)
        d_col = NEON_CYAN if dash_ready_ratio >= 1.0 else NEON_PINK
        if d_fill > 0:
            pygame.draw.rect(self.screen, d_col, (d_x, d_y, d_fill, d_h), border_radius=4)
        pygame.draw.rect(self.screen, WHITE, (d_x, d_y, d_w, d_h), width=2, border_radius=4)

        # 3) BÖLÜM ADI VE ZORLUK (Ortada)
        sec_surf = self.font_hud.render(
            f"[{self.current_level_idx:02d}/{self.max_levels:02d}] {self.level.name}  //  {self.level.difficulty_label}",
            True, NEON_YELLOW
        )
        self.screen.blit(sec_surf, (SCREEN_WIDTH // 2 - sec_surf.get_width() // 2, 12))

        hint_surf = self.font_small.render(
            "A/D veya Yön: Hareket  |  SPACE: Çift Zıplama  |  SHIFT: Dash  |  R: 1. Sektöre Dön",
            True, WHITE
        )
        self.screen.blit(hint_surf, (SCREEN_WIDTH // 2 - hint_surf.get_width() // 2, 38))

        # 4) SKOR GÖSTERGESİ (Sağ Üstte)
        score_surf = self.font_subtitle.render(f"SKOR: {self.score:05d}", True, NEON_GREEN)
        self.screen.blit(score_surf, (SCREEN_WIDTH - score_surf.get_width() - 28, 18))

        # Bölüm başlangıç neon pankartı
        if self.level_banner_ms > 0:
            alpha = min(230, int(self.level_banner_ms * 0.25))
            banner = pygame.Surface((560, 86), pygame.SRCALPHA)
            pygame.draw.rect(banner, (12, 10, 32, alpha), (0, 0, 560, 86), border_radius=10)
            pygame.draw.rect(banner, (*NEON_CYAN, alpha), (0, 0, 560, 86), width=2, border_radius=10)
            t1 = self.font_subtitle.render(self.level.name, True, NEON_CYAN)
            t2 = self.font_hud.render(self.level.difficulty_label, True, NEON_MAGENTA)
            banner.blit(t1, (280 - t1.get_width() // 2, 14))
            banner.blit(t2, (280 - t2.get_width() // 2, 48))
            self.screen.blit(banner, (SCREEN_WIDTH // 2 - 280, 110))

    def draw_overlay_screen(self, title_text, title_color, subtitle_text, extra_lines):
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        pygame.draw.rect(overlay, (8, 6, 22, 195), (0, 0, SCREEN_WIDTH, SCREEN_HEIGHT))
        self.screen.blit(overlay, (0, 0))

        card_w, card_h = 740, 440
        cx = SCREEN_WIDTH // 2 - card_w // 2
        cy = SCREEN_HEIGHT // 2 - card_h // 2

        pygame.draw.rect(self.screen, (16, 14, 40), (cx, cy, card_w, card_h), border_radius=14)
        pygame.draw.rect(self.screen, title_color, (cx, cy, card_w, card_h), width=3, border_radius=14)

        # Başlık
        title_surf = self.font_title.render(title_text, True, title_color)
        self.screen.blit(title_surf, (SCREEN_WIDTH // 2 - title_surf.get_width() // 2, cy + 36))

        sub_surf = self.font_subtitle.render(subtitle_text, True, WHITE)
        self.screen.blit(sub_surf, (SCREEN_WIDTH // 2 - sub_surf.get_width() // 2, cy + 108))

        pygame.draw.line(
            self.screen, NEON_CYAN,
            (cx + 60, cy + 152), (cx + card_w - 60, cy + 152), 2
        )

        for i, (line_text, col) in enumerate(extra_lines):
            line_surf = self.font_hud.render(line_text, True, col)
            self.screen.blit(line_surf, (SCREEN_WIDTH // 2 - line_surf.get_width() // 2, cy + 178 + i * 38))

    def draw(self):
        time_ms = pygame.time.get_ticks()
        cam_x = self.camera_x + self.screen_shake.offset_x
        cam_y = self.camera_y + self.screen_shake.offset_y

        # 1) Prosedürel Paralaks Cyberpunk Arka Planı
        self.background.draw(self.screen, cam_x, cam_y, time_ms)

        if self.state == "MENU":
            self.draw_overlay_screen(
                "NEON RUNNER // 2099",
                NEON_CYAN,
                "CYBERPUNK 2D PLATFORM OYUNU (10 SEKTÖR)",
                [
                    ("[ENTER] veya [SPACE] : 1. SEKTÖRDEN BAŞLA", NEON_GREEN),
                    ("[1 - 9] ve [0] Tuşları : İstediğin Sektörden (1 - 10) Başla", NEON_YELLOW),
                    ("HAREKET: A / D veya Sol / Sağ Ok Tuşları", WHITE),
                    ("ÇİFT ZIPLAMA (Double Jump + Coyote Time): SPACE / W / Yukarı Ok", NEON_CYAN),
                    ("NEON ATILMA (Dash + Hayalet İz): SHIFT (Dronları Yok Eder!)", NEON_MAGENTA),
                    ("[R] : 1. Sektöre Dön  |  [F11] : Tam Ekran  |  [ESC] : Çıkış", WHITE),
                ]
            )
        else:
            # 2) Bölüm, Oyuncu ve Parçacıkları Çiz
            self.level.draw(self.screen, cam_x, cam_y, time_ms)
            self.particles.draw(self.screen, cam_x, cam_y)
            if self.state != "GAME_OVER":
                self.player.draw(self.screen, cam_x, cam_y)
            self.draw_hud()

            if self.state == "GAME_OVER":
                self.draw_overlay_screen(
                    "SİSTEM ÇÖKTÜ // GAME OVER",
                    NEON_RED,
                    f"TOPLAM SKOR: {self.score:05d}   |   SEKTÖR: {self.current_level_idx:02d}/{self.max_levels:02d}",
                    [
                        ("Siber zırhın parçalandı veya boşluğa düştün!", NEON_PINK),
                        (f"[ENTER / SPACE] : Kaldığın Sektörden (Sektör {self.current_level_idx:02d}) Devam Et", NEON_GREEN),
                        ("[R] Tuşuna Basarak 1. Sektöre Dön (Baştan Başla)", NEON_CYAN),
                        ("[ESC] : Ana Menüye Dön", WHITE),
                    ]
                )
            elif self.state == "VICTORY":
                self.draw_overlay_screen(
                    "OMEGA NEXUS ELE GEÇİRİLDİ!",
                    NEON_GREEN,
                    f"TEBRİKLER! FİNAL SKORU: {self.score:05d}",
                    [
                        (f"Tüm {self.max_levels} Cyberpunk Sektörünü Başarıyla Tamamladın!", NEON_YELLOW),
                        ("[R] veya [ENTER / SPACE] : Tekrar Oyna", NEON_CYAN),
                        ("[ESC] : Ana Menüye Dön", WHITE),
                    ]
                )

        pygame.display.flip()

    async def run(self):
        while self.running:
            dt_ms = self.clock.tick(FPS)
            self.handle_events()
            if not self.running:
                break
            self.update(dt_ms)
            self.draw()
            await asyncio.sleep(0)
        pygame.quit()


async def main():
    game = CyberpunkGame()
    await game.run()


if __name__ == "__main__":
    asyncio.run(main())
