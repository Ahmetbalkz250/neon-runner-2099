# player.py
# Cyberpunk Karakter Kontrolleri, Fizik (Coyote Time, Double Jump, Dash) ve Prosedürel Çizim

import math
import pygame
from settings import (
    PLAYER_WIDTH, PLAYER_HEIGHT,
    PLAYER_ACCEL, PLAYER_FRICTION, PLAYER_AIR_RESISTANCE, PLAYER_MAX_SPEED,
    GRAVITY, MAX_FALL_SPEED, JUMP_FORCE, DOUBLE_JUMP_FORCE,
    COYOTE_TIME_MS, JUMP_BUFFER_MS,
    DASH_SPEED, DASH_DURATION_MS, DASH_COOLDOWN_MS, DASH_TRAIL_INTERVAL_MS,
    PLAYER_MAX_HP, INVULNERABLE_MS,
    NEON_CYAN, NEON_MAGENTA, NEON_PINK, NEON_YELLOW, WHITE, DARK_METAL
)


class Player:
    def __init__(self, x, y):
        self.spawn_x = float(x)
        self.spawn_y = float(y)
        self.rect = pygame.Rect(int(x), int(y), PLAYER_WIDTH, PLAYER_HEIGHT)
        self.pos_x = float(x)
        self.pos_y = float(y)
        self.vel_x = 0.0
        self.vel_y = 0.0

        # Durum değişkenleri
        self.on_ground = False
        self.was_on_ground = False
        self.facing_right = True
        self.jumps_left = 2

        # Zamanlayıcılar (ms)
        self.coyote_timer_ms = 0.0
        self.jump_buffer_ms = 0.0

        # Dash (Atılma) durumu
        self.is_dashing = False
        self.dash_timer_ms = 0.0
        self.dash_cooldown_ms = 0.0
        self.dash_trail_timer_ms = 0.0
        self.dash_dir = 1

        # Can ve Hasar
        self.hp = PLAYER_MAX_HP
        self.invulnerable_ms = 0.0

        # Görsel Squash & Stretch ve Eşarp/Pelerin noktaları
        self.scale_x = 1.0
        self.scale_y = 1.0
        self.scarf_points = [(self.pos_x, self.pos_y + 14) for _ in range(6)]
        self.riding_platform = None

    def reset(self, x=None, y=None):
        if x is not None:
            self.spawn_x = float(x)
        if y is not None:
            self.spawn_y = float(y)
        self.pos_x = self.spawn_x
        self.pos_y = self.spawn_y
        self.rect.topleft = (int(self.pos_x), int(self.pos_y))
        self.vel_x = 0.0
        self.vel_y = 0.0
        self.on_ground = False
        self.was_on_ground = False
        self.jumps_left = 2
        self.coyote_timer_ms = 0.0
        self.jump_buffer_ms = 0.0
        self.is_dashing = False
        self.dash_timer_ms = 0.0
        self.dash_cooldown_ms = 0.0
        self.hp = PLAYER_MAX_HP
        self.invulnerable_ms = 0.0
        self.scale_x = 1.0
        self.scale_y = 1.0
        self.riding_platform = None
        self.scarf_points = [(self.pos_x, self.pos_y + 14) for _ in range(6)]

    def request_jump(self):
        """Space / W / Up basıldığında çağrılır."""
        self.jump_buffer_ms = JUMP_BUFFER_MS

    def request_dash(self, particles, screen_shake):
        """Shift basıldığında çağrılır."""
        if self.dash_cooldown_ms <= 0 and not self.is_dashing:
            self.is_dashing = True
            self.dash_timer_ms = DASH_DURATION_MS
            self.dash_cooldown_ms = DASH_COOLDOWN_MS
            self.dash_trail_timer_ms = 0.0
            self.dash_dir = 1 if self.facing_right else -1
            self.vel_x = self.dash_dir * DASH_SPEED
            self.vel_y = 0.0
            self.scale_x = 1.35
            self.scale_y = 0.72
            particles.emit_dash(self.rect.centerx, self.rect.centery, self.dash_dir)
            particles.add_afterimage(
                self.rect.x, self.rect.y, self.rect.width, self.rect.height,
                NEON_CYAN, self.facing_right
            )
            screen_shake.trigger(intensity=6, duration_ms=140)

    def take_damage(self, amount, knockback_dir, particles, screen_shake):
        if self.invulnerable_ms > 0 or self.is_dashing:
            return False
        self.hp = max(0, self.hp - amount)
        self.invulnerable_ms = INVULNERABLE_MS
        self.vel_y = -8.5
        self.vel_x = knockback_dir * 7.5
        particles.emit_explosion(self.rect.centerx, self.rect.centery, color=NEON_MAGENTA, count=26)
        screen_shake.trigger(intensity=11, duration_ms=260)
        return True

    def update(self, dt_ms, keys, platforms, moving_platforms, particles, screen_shake):
        dt_scale = min(2.5, dt_ms / 16.67)

        # Zamanlayıcıları güncelle
        if self.coyote_timer_ms > 0:
            self.coyote_timer_ms = max(0.0, self.coyote_timer_ms - dt_ms)
        if self.jump_buffer_ms > 0:
            self.jump_buffer_ms = max(0.0, self.jump_buffer_ms - dt_ms)
        if self.dash_cooldown_ms > 0:
            self.dash_cooldown_ms = max(0.0, self.dash_cooldown_ms - dt_ms)
        if self.invulnerable_ms > 0:
            self.invulnerable_ms = max(0.0, self.invulnerable_ms - dt_ms)

        # Hareketli platformun üzerinde miyiz?
        if self.on_ground and self.riding_platform is not None:
            self.pos_x += self.riding_platform.delta_x
            self.pos_y += self.riding_platform.delta_y
            self.rect.topleft = (int(round(self.pos_x)), int(round(self.pos_y)))

        # Yatay girdi (WASD veya Yön Tuşları)
        move_dir = 0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            move_dir -= 1
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            move_dir += 1

        if move_dir != 0 and not self.is_dashing:
            self.facing_right = (move_dir > 0)

        # Dash güncellemesi
        if self.is_dashing:
            self.dash_timer_ms -= dt_ms
            self.dash_trail_timer_ms -= dt_ms
            self.vel_x = self.dash_dir * DASH_SPEED
            self.vel_y = 0.0
            if self.dash_trail_timer_ms <= 0:
                self.dash_trail_timer_ms = DASH_TRAIL_INTERVAL_MS
                trail_col = NEON_CYAN if int(self.dash_timer_ms) % 2 == 0 else NEON_MAGENTA
                particles.add_afterimage(
                    self.rect.x, self.rect.y, self.rect.width, self.rect.height,
                    trail_col, self.facing_right
                )
            if self.dash_timer_ms <= 0:
                self.is_dashing = False
                self.vel_x = self.dash_dir * (PLAYER_MAX_SPEED * 0.85)
        else:
            # Normal yatay hızlanma ve sürtünme
            if move_dir != 0:
                self.vel_x += move_dir * PLAYER_ACCEL * dt_scale
                if abs(self.vel_x) > PLAYER_MAX_SPEED:
                    self.vel_x = math.copysign(PLAYER_MAX_SPEED, self.vel_x)
            else:
                friction = PLAYER_FRICTION if self.on_ground else PLAYER_AIR_RESISTANCE
                self.vel_x *= pow(friction, dt_scale)
                if abs(self.vel_x) < 0.15:
                    self.vel_x = 0.0

            # Yerçekimi
            self.vel_y += GRAVITY * dt_scale
            if self.vel_y > MAX_FALL_SPEED:
                self.vel_y = MAX_FALL_SPEED

        # Zıplama Mantığı (Coyote Time + Jump Buffer + Double Jump)
        if self.jump_buffer_ms > 0:
            # 1) Yerdeyken veya Coyote Time süresindeyken ilk zıplama
            if self.on_ground or self.coyote_timer_ms > 0:
                self.vel_y = JUMP_FORCE
                self.on_ground = False
                self.coyote_timer_ms = 0.0
                self.jump_buffer_ms = 0.0
                self.jumps_left = 1
                self.riding_platform = None
                self.scale_x = 0.76
                self.scale_y = 1.28
                particles.emit_jump(self.rect.centerx, self.rect.bottom, is_double=False)
                if self.is_dashing:
                    self.is_dashing = False
            # 2) Havadayken Çift Zıplama (Double Jump)
            elif self.jumps_left > 0:
                self.vel_y = DOUBLE_JUMP_FORCE
                self.jumps_left -= 1
                self.jump_buffer_ms = 0.0
                self.scale_x = 0.72
                self.scale_y = 1.32
                particles.emit_jump(self.rect.centerx, self.rect.bottom, is_double=True)
                particles.add_afterimage(
                    self.rect.x, self.rect.y, self.rect.width, self.rect.height,
                    NEON_MAGENTA, self.facing_right
                )
                if self.is_dashing:
                    self.is_dashing = False

        # Tüm katı platformları birleştir
        all_platforms = list(platforms) + list(moving_platforms)

        # Yatay Hareket ve Çarpışma
        self.pos_x += self.vel_x * dt_scale
        self.rect.x = int(round(self.pos_x))
        for plat in all_platforms:
            if self.rect.colliderect(plat.rect):
                if self.vel_x > 0:
                    self.rect.right = plat.rect.left
                    self.pos_x = float(self.rect.x)
                    self.vel_x = 0.0
                elif self.vel_x < 0:
                    self.rect.left = plat.rect.right
                    self.pos_x = float(self.rect.x)
                    self.vel_x = 0.0

        # Dikey Hareket ve Çarpışma
        self.was_on_ground = self.on_ground
        self.on_ground = False
        self.riding_platform = None
        impact_vel_y = self.vel_y

        self.pos_y += self.vel_y * dt_scale
        self.rect.y = int(round(self.pos_y))
        for plat in all_platforms:
            if self.rect.colliderect(plat.rect):
                if self.vel_y > 0:
                    self.rect.bottom = plat.rect.top
                    self.pos_y = float(self.rect.y)
                    self.vel_y = 0.0
                    self.on_ground = True
                    self.jumps_left = 2
                    if plat in moving_platforms:
                        self.riding_platform = plat
                elif self.vel_y < 0:
                    self.rect.top = plat.rect.bottom
                    self.pos_y = float(self.rect.y)
                    self.vel_y = 0.0

        # Coyote Time ve İniş (Landing) Efektleri
        if self.on_ground:
            self.coyote_timer_ms = COYOTE_TIME_MS
            if not self.was_on_ground and impact_vel_y > 4.0:
                self.scale_x = 1.28
                self.scale_y = 0.75
                particles.emit_land(self.rect.centerx, self.rect.bottom, impact_vel_y)
                if impact_vel_y > 12.0:
                    screen_shake.trigger(intensity=5, duration_ms=110)
        else:
            # Platformdan yeni düştüysek ve zıplamadıysak ilk zıplama hakkı coyote_timer_ms boyunca korunur,
            # coyote süresi bittiğinde havadaki tek zıplama (double jump) hakkına düşer.
            if self.coyote_timer_ms <= 0 and self.jumps_left == 2:
                self.jumps_left = 1

        # Squash & Stretch yumuşak geri dönüş
        self.scale_x += (1.0 - self.scale_x) * 0.22 * dt_scale
        self.scale_y += (1.0 - self.scale_y) * 0.22 * dt_scale

        # Neon eşarp/iz noktalarını güncelle
        anchor_x = self.rect.centerx - (6 if self.facing_right else -6)
        anchor_y = self.rect.top + 14
        self.scarf_points[0] = (anchor_x, anchor_y)
        for i in range(1, len(self.scarf_points)):
            px, py = self.scarf_points[i - 1]
            cx, cy = self.scarf_points[i]
            trail_dir = -1 if self.facing_right else 1
            target_x = px + trail_dir * 6
            target_y = py + math.sin(pygame.time.get_ticks() * 0.015 + i) * 1.8
            self.scarf_points[i] = (cx + (target_x - cx) * 0.45, cy + (target_y - cy) * 0.45)

    def draw(self, surface, camera_x, camera_y):
        # Hasar aldıysa yanıp sönme efekti
        if self.invulnerable_ms > 0 and (int(self.invulnerable_ms // 60) % 2 == 1):
            return

        # Neon Sibernetik Eşarp / Pelerin İzi
        if len(self.scarf_points) >= 2:
            pts = [(int(px - camera_x), int(py - camera_y)) for px, py in self.scarf_points]
            scarf_col = NEON_MAGENTA if self.jumps_left < 2 else NEON_CYAN
            pygame.draw.lines(surface, scarf_col, False, pts, 4)

        # Squash & Stretch hesaplaması (alt merkez sabit kalacak şekilde)
        draw_w = int(self.rect.width * self.scale_x)
        draw_h = int(self.rect.height * self.scale_y)
        draw_x = int(self.rect.centerx - draw_w // 2 - camera_x)
        draw_y = int(self.rect.bottom - draw_h - camera_y)

        # Dış Neon Parlama (Glow)
        glow_col = NEON_MAGENTA if self.is_dashing else NEON_CYAN
        glow_surf = pygame.Surface((draw_w + 16, draw_h + 16), pygame.SRCALPHA)
        pygame.draw.rect(
            glow_surf, (*glow_col, 70),
            (4, 4, draw_w + 8, draw_h + 8), border_radius=8
        )
        surface.blit(glow_surf, (draw_x - 8, draw_y - 8), special_flags=pygame.BLEND_ADD)

        # Ana Sibernetik Gövde
        body_rect = pygame.Rect(draw_x, draw_y, draw_w, draw_h)
        pygame.draw.rect(surface, DARK_METAL, body_rect, border_radius=6)
        pygame.draw.rect(surface, glow_col, body_rect, width=2, border_radius=6)

        # Göğüs Enerji Çekirdeği
        core_col = NEON_YELLOW if self.dash_cooldown_ms <= 0 else NEON_PINK
        core_rect = pygame.Rect(draw_x + draw_w // 2 - 4, draw_y + int(draw_h * 0.52), 8, 8)
        pygame.draw.rect(surface, core_col, core_rect, border_radius=2)

        # Cyberpunk Visor (Gözlük)
        visor_w = max(10, int(draw_w * 0.52))
        visor_h = max(5, int(draw_h * 0.16))
        visor_x = draw_x + draw_w - visor_w - 2 if self.facing_right else draw_x + 2
        visor_y = draw_y + int(draw_h * 0.20)
        pygame.draw.rect(surface, NEON_MAGENTA, (visor_x, visor_y, visor_w, visor_h), border_radius=3)
        pygame.draw.rect(surface, WHITE, (visor_x + 2, visor_y + 1, max(4, visor_w - 4), max(2, visor_h // 2)), border_radius=2)
